﻿using lab_7_lev_1_3;
using lab_7_lev_1_3.MySer;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace lab_7_lev_1_3
{
    [Serializable]
    [ProtoContract]
    [XmlInclude(typeof(PersonOfYear)), ProtoInclude(2, typeof(PersonOfYear))]
    [XmlInclude(typeof(DiscoveryOfYear)), ProtoInclude(3, typeof(DiscoveryOfYear))]
    public abstract class Answer
    {
        protected string _surname;
        protected int _number;
        [XmlAttribute("Surname")]
        [ProtoMember(4)]
        public string Surname {
            get { return _surname; }
            set { _surname = value; } 
        }                     
        [XmlAttribute("Number")]
        [ProtoMember(5)]
        public int Number {
            get { return _number; }
            set { _number = value; }
        }

        public Answer() { }
        [JsonConstructor]
        public Answer(string surname, int number)
        {
            _surname = surname;
            _number = number;

        }
        public virtual void Print()
        {
            double n = _number;
            Console.WriteLine("Фамилия {0}   \t {1} голосов", _surname, _number);
        }
    }
    [ProtoContract]
    public class PersonOfYear : Answer
    {
        private static int _totalPersonVotes = 0;
        public PersonOfYear() { }
        [JsonConstructor]
        public PersonOfYear(string surname, int number) : base(surname, number)
        {
            _totalPersonVotes += number;
        }
        public override void Print()
        {
            Console.WriteLine("Фамилия {0}   \t {1} голосов\t доля {2}%", _surname, _number, ((_number / (double)_totalPersonVotes) * 100));
        }

    }
    [ProtoContract]
    public class DiscoveryOfYear : Answer
    {
        private static int _totalDiscoveryVotes = 0;
        public DiscoveryOfYear() { }
        [JsonConstructor]
        public DiscoveryOfYear(string surname, int number) : base(surname, number)
        {
            _totalDiscoveryVotes += number;
        }
        public override void Print()
        {

            Console.WriteLine("Фамилия {0}\t {1} голосов\t доля {2:F2}%", _surname, _number, ((_number / (double)_totalDiscoveryVotes) * 100));
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            PersonOfYear[] per = new PersonOfYear[8];
            per[0] = new PersonOfYear("Нагиев", 8);
            per[1] = new PersonOfYear("Ургант", 4);
            per[2] = new PersonOfYear("Малышева", 2);
            per[3] = new PersonOfYear("Пелевин", 10);
            per[4] = new PersonOfYear("Малахов", 7);
            per[5] = new PersonOfYear("Янковский", 5);
            per[6] = new PersonOfYear("Богомолов", 3);
            per[7] = new PersonOfYear("Пересильд", 1);

            DiscoveryOfYear[] dis = new DiscoveryOfYear[6];
            dis[0] = new DiscoveryOfYear("Лекарство от бессоницы", 5);
            dis[1] = new DiscoveryOfYear("Солнечная батарея     ", 7);
            dis[2] = new DiscoveryOfYear("Электрокар            ", 2);
            dis[3] = new DiscoveryOfYear("VR очки               ", 10);
            dis[4] = new DiscoveryOfYear("3D принтер            ", 5);
            dis[5] = new DiscoveryOfYear("Метавселенные         ", 3);


            Sort(per);
            Sort(dis);

            string path = @"C:\Users\user\Desktop"; //путь до рабочего стола
            string folderName = "Test";
            path = Path.Combine(path, folderName);
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            Serialize[] mySerializers = new Serialize[3];
            mySerializers[0] = new MyJsonSerializer();
            mySerializers[1] = new MyXmlSerializer();
            mySerializers[2] = new MyBinSerializer();
            string[] file_names = new string[]
            {
                "result.json",
                "result.xml",
                "result.bin"
            };

            for (int i = 0; i < mySerializers.Length; i++)
            {
                File.WriteAllText(Path.Combine(path, file_names[i]), string.Empty);
                mySerializers[i].Write(per, Path.Combine(path, file_names[i]));
            } 
            Console.WriteLine("PersonOfYear");
            for(int i = 0; i < mySerializers.Length; ++i)
            {
                var answer = mySerializers[i].Read<PersonOfYear[]>(Path.Combine(path, file_names[i]));
                for (int j = 0; j < 5; j++)
                {
                    answer[j].Print();
                }
            }

            Console.WriteLine("");

           for (int i = 0; i < mySerializers.Length; i++)
            {
                File.WriteAllText(Path.Combine(path, file_names[i]), string.Empty);
                mySerializers[i].Write(dis, Path.Combine(path, file_names[i]));
            }
            Console.WriteLine("DiscoveryOfYear");
            for (int i = 0; i < mySerializers.Length; ++i)
            {
                var answer = mySerializers[i].Read<DiscoveryOfYear[]>(Path.Combine(path, file_names[i]));
                for (int j = 0; j < 5; j++)
                {
                    answer[j].Print();
                }
            }
            Console.ReadKey();
        }
        static void Sort(Answer[] an)
        {
            for (int i = 1; i < an.Length; i++)
            {
                Answer temp = an[i];
                int j;
                for (j = i; j > 0 && temp.Number.CompareTo(an[j - 1].Number) > 0; j--)
                {
                    an[j] = an[j - 1];
                }
                an[j] = temp;
            }
        }
    }
}

