﻿using lab_7_lev_1_3.MySer;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace lab7_lev3_3
{
    [Serializable]
    [ProtoContract]
    [XmlInclude(typeof(Women)), ProtoInclude(1, typeof(Women))]
    [XmlInclude(typeof(Men)), ProtoInclude(2, typeof(Men))]
    public class Team
    {
        protected string _name;
        protected int[] _places;
        protected int _points;

        [XmlAttribute("Name")]
        [ProtoMember(3)]
        public string Name
        {
            get {  return _name; }
            set { _name = value; }
        }
        [XmlAttribute("Places")]
        [ProtoMember(4)]
        public int[] Places {
            get { return _places; }
            set { _places = value; }
        }
        [XmlAttribute("Pints")]
        [ProtoMember(5)]
        public int Points
        {
            get { return _points; }
            set { _points = value; }
        }

        public Team() { }
        [JsonConstructor]
        public Team(string name, int[] places, int points)
        {
            _name = name;
            _places = places;
            _points = points;
        }
        public void CalculatePoints()
        {
            int totalPoints = 0;
            for (int i = 0; i < _places.Length; i++)
            {
                if (_places[i] <= 5)
                {
                    totalPoints += (6 - _places[i]);
                }
            }
            _points = totalPoints;
        }

        public static Team Winner(params Team[] teams)
        {
            Team winner = teams[0];
            foreach (Team team in teams)
            {
                if (team.Points > winner.Points)
                {
                    winner = team;
                }
                else if (team.Points == winner.Points && team.Places[0] == 1)
                {
                    winner = team;
                }
            }
            return winner;
        }
    }
    [ProtoContract]
    public class Women : Team
    {
        public Women() { }
        public Women(string name, int[] places, int points) : base(name, places, points)
        {

        }
    }
    [ProtoContract]
    public class Men : Team
    {
        public Men() {  }
        public Men(string name, int[] places, int points) : base(name, places, points)
        {

        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {

            Women[] women = new Women[3];
            women[0] = new Women("A", new int[] { 1, 2, 3, 9, 17, 4 }, 0);
            women[1] = new Women("B", new int[] { 7, 6, 10, 14, 18, 12 }, 0);
            women[2] = new Women("C", new int[] { 5, 7, 11, 15, 16, 13 }, 0);

            Men[] men = new Men[3];
            men[0] = new Men("D", new int[] { 11, 8, 9, 13, 17, 4 }, 0);
            men[1]= new Men("E", new int[] { 1, 2, 3, 4, 5, 6 }, 0);
            men[2] = new Men("F", new int[] { 3, 2, 1, 15, 16, 5 }, 0);

            foreach(var i in men)
            {
                i.CalculatePoints();
            }
            foreach (var i in women)
            {
                i.CalculatePoints();
            }

            Team[] team = new Team[2]; 
            team[0] = Team.Winner(men[0], men[1], men[2]);
            team[1] = Team.Winner(women[0], women[1], women[2]);

            string path = @"C:\Users\user\Desktop"; //путь до рабочего стола
            string folderName = "Test";
            path = Path.Combine(path, folderName);
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            Serialize[] mySerializers = new Serialize[3];
            mySerializers[0] = new MyJsonSerializer();
            mySerializers[1] = new MyXmlSerializer();
            mySerializers[2] = new MyBinSerializer();
            string[] file_names = new string[]
            {
                "result.json",
                "result.xml",
                "result.bin"
            };

            for (int i = 0; i < mySerializers.Length; i++)
            {
                File.WriteAllText(Path.Combine(path, file_names[i]), string.Empty);
                mySerializers[i].Write(team, Path.Combine(path, file_names[i]));
            }
            for(int i= 0;  i < mySerializers.Length; i++)
            {
                var answer = mySerializers[i].Read<Team[]>(Path.Combine(path, file_names[i]));
                if (answer[0].Points > answer[1].Points)
                {
                    Console.WriteLine("Победила команда {0} набрав {1} очков", answer[0].Name, answer[1].Points);
                }
                else
                {
                    Console.WriteLine("Победила команда {0} набрав {1} очков", answer[0].Name, answer[1].Points);
                }
            }
            
            Console.ReadKey();
        }
    }
}

