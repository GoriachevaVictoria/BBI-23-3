﻿using lab_7_lev_1_3.MySer;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace lab_7_lev_2_3
{
    [Serializable]
    [ProtoContract]
    [XmlInclude(typeof(LongJump)), ProtoInclude(1, typeof(LongJump))]
    [XmlInclude(typeof(HighJump)), ProtoInclude(2, typeof(HighJump))]
    public abstract class Discipline
    {
        protected string _surname;
        protected double _res1;
        protected double _res2;
        protected double _res3;
        protected double _maxres;
        protected string _disciplineName;

        [XmlAttribute("Surname")]
        [ProtoMember(3)]
        public string _Surname{
            get { return _surname; }
            set { _surname = value; }
        }
        [XmlAttribute("MaxRes")]
        [ProtoMember(4)]
        public double _Maxres
        {
            get { return _maxres; }
            set { _maxres = value; }
        }

        [XmlAttribute("Result 1")]
        [ProtoMember(5)]
        public double _Res1
        {
            get { return _res1; }
            set { _res1 = value; }
        }

        [XmlAttribute("Result 2")]
        [ProtoMember(6)]
        public double _Res2
        {
            get { return _res2; }
            set { _res2 = value; }
        }

        [XmlAttribute("Result 3")]
        [ProtoMember(7)]
        public double _Res3
        {
            get { return _res3; }
            set { _res3 = value; }
        }

        public Discipline() { }
        [JsonConstructor]
        public Discipline(string surname, double res1, double res2, double res3, double maxres, string disciplineName)
        {
            _surname = surname;
            _res1 = res1;
            _res2 = res2;
            _res3 = res3;
            _maxres = maxres;
            _disciplineName = disciplineName;
        }
        public virtual void PrintHeader()
        {
            Console.WriteLine("Дисциплина: {0}", _disciplineName);
        }
        public virtual void Print()
        {

            Console.WriteLine("Фамилия {0}   \t {1} ", _surname, _maxres);
        }
        public void BestRes()
        {
            _maxres = Math.Max(Math.Max(_res1, _res2), _res3);
        }
    }
    [ProtoContract]
    public class LongJump : Discipline
    {
        public LongJump() { }
        public LongJump(string surname, double res1, double res2, double res3, double maxres) : base(surname, res1, res2, res3, maxres, "Прыжки в длину")
        {
            BestRes();
        }
        public override void Print()
        {

            Console.WriteLine("Фамилия {0}   \t {1} ", _surname, _maxres);
        }
    }
    [ProtoContract]
    public class HighJump : Discipline
    {
        public HighJump() { }
        public HighJump(string surname, double res1, double res2, double res3, double maxres) : base(surname, res1, res2, res3, maxres, "Прыжки в высоту")
        {
            BestRes();
        }
        public override void Print()
        {

            Console.WriteLine("Фамилия {0}   \t {1} ", _surname, _maxres);
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            LongJump[] lo = new LongJump[5];
            lo[0] = new LongJump("Иванов", 1.2, 1.4, 1.1, 0);
            lo[1] = new LongJump("Петров", 2.2, 2.1, 2.8, 0);
            lo[2] = new LongJump("Сидоров", 2.5, 1.9, 2.1, 0);
            lo[3] = new LongJump("Смирнов", 1.9, 1.8, 2.0, 0);
            lo[4] = new LongJump("Васечкин", 2.7, 2.9, 1.8, 0);

            HighJump[] high = new HighJump[5];
            high[0] = new HighJump("Иванов", 2.7, 2.9, 1.8, 0);
            high[1] = new HighJump("Петров", 2.2, 2.1, 2.9, 0);
            high[2] = new HighJump("Сидоров", 2.6, 1.9, 2.1, 0);
            high[3] = new HighJump("Смирнов", 1.9, 1.8, 2.5, 0);
            high[4] = new HighJump("Васечкин", 1.7, 2.8, 1.8, 0);

            lo[0].PrintHeader();
            string path = @"C:\Users\user\Desktop"; //путь до рабочего стола
            string folderName = "Test";
            path = Path.Combine(path, folderName);
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            Serialize[] mySerializers = new Serialize[3];
            mySerializers[0] = new MyJsonSerializer();
            mySerializers[1] = new MyXmlSerializer();
            mySerializers[2] = new MyBinSerializer();
            string[] file_names = new string[]
            {
                "result.json",
                "result.xml",
                "result.bin"
            };

            for (int i = 0; i < mySerializers.Length; i++)
            {
                File.WriteAllText(Path.Combine(path, file_names[i]), string.Empty);
                mySerializers[i].Write(lo, Path.Combine(path, file_names[i]));
            }
            for(int j = 0; j < mySerializers.Length; j++)
            {
                var answer = mySerializers[j].Read<LongJump[]>(Path.Combine(path, file_names[j]));
                foreach(var item in answer)
                {
                    item.BestRes();
                    item.Print();
                }
            }
            Console.WriteLine("");
            high[0].PrintHeader();

            for (int i = 0; i < mySerializers.Length; i++)
            {
                File.WriteAllText(Path.Combine(path, file_names[i]), string.Empty);
                mySerializers[i].Write(high, Path.Combine(path, file_names[i]));
            }
            for (int j = 0; j < mySerializers.Length; j++)
            {
                var answer = mySerializers[j].Read<HighJump[]>(Path.Combine(path, file_names[j]));
                foreach (var item in answer)
                {
                    item.BestRes();
                    item.Print();
                }
            }

            Console.ReadKey();
        }
    }
}
